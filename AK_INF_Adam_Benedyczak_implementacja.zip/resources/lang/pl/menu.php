<?php

return [
    'dashboard' => 'Panel główny',
    'add_new' => 'Dodaj nowy',
    'vehicles' => 'Pojazdy',
    'trailers' => 'Przyczepy',
    'machines' => 'Maszyny',
    'notifications' => 'Powiadomienia',
    'admin_panel' => 'Panel administracyjny',
    'choose_new' => 'Wybierz nowy',
];