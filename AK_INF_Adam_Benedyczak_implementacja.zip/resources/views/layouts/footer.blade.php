<footer class="container border-top text-center mt-3 pt-3 pb-3">
  <p>&copy; Test 2021</p>
</footer>
