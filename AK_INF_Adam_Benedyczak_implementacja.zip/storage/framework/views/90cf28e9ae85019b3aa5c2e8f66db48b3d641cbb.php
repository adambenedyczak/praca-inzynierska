

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 3])->html();
} elseif ($_instance->childHasBeenRendered('YpfwZ4K')) {
    $componentId = $_instance->getRenderedChildComponentId('YpfwZ4K');
    $componentTag = $_instance->getRenderedChildComponentTagName('YpfwZ4K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YpfwZ4K');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 3]);
    $html = $response->html();
    $_instance->logRenderedChild('YpfwZ4K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<div class="mt-md-5 mt-3 mx-2">
    <div class="row justify-content-center">
        <div class="col-xl-10 col-md-10">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object-full', ['object_id' => $machine->id])->html();
} elseif ($_instance->childHasBeenRendered('u0BPUYv')) {
    $componentId = $_instance->getRenderedChildComponentId('u0BPUYv');
    $componentTag = $_instance->getRenderedChildComponentTagName('u0BPUYv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('u0BPUYv');
} else {
    $response = \Livewire\Livewire::mount('display-object-full', ['object_id' => $machine->id]);
    $html = $response->html();
    $_instance->logRenderedChild('u0BPUYv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>
    </div>      
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/machines/show.blade.php ENDPATH**/ ?>