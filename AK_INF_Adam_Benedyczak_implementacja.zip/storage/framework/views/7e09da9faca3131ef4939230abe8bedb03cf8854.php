<div class="row justify-content-center m-0 p-0">
    <div class="col-12 col-md-10 col-lg-6 text-center p-0 m-0">
        <div class="btn-group shadow-sm" role="group" aria-label="Basic example">
            <?php if($tmp == 1): ?>
                <a href="<?php echo e(route('vehicles.index')); ?>" type="button" class="btn btn-primary">
            <?php else: ?>
                <a href="<?php echo e(route('vehicles.index')); ?>" type="button" class="btn btn-outline-primary">
            <?php endif; ?>
                Pojazdy
            </a>
            <?php if($tmp == 2): ?>
            <a href="<?php echo e(route('trailers.index')); ?>" type="button" class="btn btn-primary">
            <?php else: ?>
            <a href="<?php echo e(route('trailers.index')); ?>" type="button" class="btn btn-outline-primary">
            <?php endif; ?>
                Przyczepy
            </a>
            <?php if($tmp == 3): ?>
            <a href="<?php echo e(route('machines.index')); ?>" type="button" class="btn btn-primary">
            <?php else: ?>
            <a href="<?php echo e(route('machines.index')); ?>" type="button" class="btn btn-outline-primary">
            <?php endif; ?>
                Maszyny
            </a>
            <a href="<?php echo e(route('objects.create')); ?>" type="button" class="btn btn-outline-success">
                Nowy
            </a>
        </div>
    </div>
</div>

<?php /**PATH C:\htdocs\inz\resources\views/livewire/mini-nav-bar.blade.php ENDPATH**/ ?>