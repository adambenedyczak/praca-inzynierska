<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 0])->html();
} elseif ($_instance->childHasBeenRendered('5Tk1B47')) {
    $componentId = $_instance->getRenderedChildComponentId('5Tk1B47');
    $componentTag = $_instance->getRenderedChildComponentTagName('5Tk1B47');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5Tk1B47');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('5Tk1B47', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php if(session()->has('message')): ?>
    <div class="row justify-content-center m-2"> 
        <div class="col-xl-10 col-md-12 p-0">        
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>        
        </div>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center m-2">
        <div class="col-xl-10 col-md-12 p-0">
            <div class="card border-primary " >
                <div class="card-body p-2 p-sm-3">                   
                    <div class="container">
                        <div class="row">
                            <div class="col-9">
                                <h5 class="card-title mt-2"><?php echo e(__('Ustawienia powiadomień')); ?></h5>
                                <small>Wybierz ile dni wcześniej chcesz otrzymać powiadomienie</small>
                            </div>
                        </div>
                        <div>
                            <hr/>
                        </div>
                        <div class="row my-3">
                            <div class="col-md-4 px-3">
                                <div class="container">
                                    <div class="row my-2">
                                        <h6>Powiadomienia o częściach</h6>
                                    </div>
                                    <div class="row my-2">
                                        <div class="form-group">
                                            <div class="custom-control custom-switch">
                                                <input wire:model="isEnabledNotificationPart" type="checkbox" class="custom-control-input" id="customSwitch1" checked="">
                                                <label class="custom-control-label" for="customSwitch1">Włącz powiadomienia</label>
                                            </div>
                                            <?php if($isEnabledNotificationPart): ?>
                                            <select wire:model="notificationPartTime" class="custom-select my-2 form-control">
                                            <?php else: ?>
                                            <select wire:model="notificationPartTime" class="custom-select my-2 form-control" disabled="disabled">
                                            <?php endif; ?>
                                                <?php $__currentLoopData = $notificationTimeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($time['time']); ?>"><?php echo e($time['description']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if($isEnabledNotificationPart == false): ?>
                                    <div class="row my-2 pr-4">
                                        <div class="card bg-warning">
                                            <div class="card-body p-2 m-0">
                                                Wyłączono powiadomienia o częściach!
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4 px-3">
                                <div class="container">
                                    <div class="row my-2">
                                        <h6>Powiadomienia o przeglądach</h6>
                                    </div>
                                    <div class="row my-2">
                                        <div class="form-group">
                                            <div class="custom-control custom-switch">
                                                <input wire:model="isEnabledNotificationOverview" type="checkbox" class="custom-control-input" id="customSwitch2" checked="">
                                                <label class="custom-control-label" for="customSwitch2">Włącz powiadomienia</label>
                                            </div>
                                            <?php if($isEnabledNotificationOverview): ?>
                                            <select wire:model="notificationOverviewTime" class="custom-select my-2 form-control">
                                            <?php else: ?>
                                            <select wire:model="notificationOverviewTime" class="custom-select my-2 form-control" disabled="disabled">
                                            <?php endif; ?>
                                                <?php $__currentLoopData = $notificationTimeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($time['time']); ?>"><?php echo e($time['description']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if($isEnabledNotificationOverview == false): ?>
                                    <div class="row my-2 pr-4">
                                        <div class="card bg-warning">
                                            <div class="card-body p-2 m-0">
                                                Wyłączono powiadomienia o przeglądach!
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4 px-3">
                                <div class="container">
                                    <div class="row my-2">
                                        <h6>Powiadomienia o ubezpieczeniach</h6>
                                    </div>
                                    <div class="row my-2">
                                        <div class="form-group">
                                            <div class="custom-control custom-switch">
                                                <input wire:model="isEnabledNotificationInsurance" type="checkbox" class="custom-control-input" id="customSwitch3" checked="">
                                                <label class="custom-control-label" for="customSwitch3">Włącz powiadomienia</label>
                                            </div>
                                            <?php if($isEnabledNotificationInsurance): ?>
                                            <select wire:model="notificationInsuranceTime" class="custom-select my-2 form-control">
                                            <?php else: ?>
                                            <select wire:model="notificationInsuranceTime" class="custom-select my-2 form-control" disabled="disabled">
                                            <?php endif; ?>
                                                <?php $__currentLoopData = $notificationTimeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($time['time']); ?>"><?php echo e($time['description']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if($isEnabledNotificationInsurance == false): ?>
                                    <div class="row my-2 pr-4">
                                        <div class="card bg-warning">
                                            <div class="card-body p-2 m-0">
                                                Wyłączono powiadomienia o ubezpieczeniach!
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row my-3 justify-content-end mr-md-3 mr-0">
                            <button wire:click="saveNotificationRuleChanges" type="button" class="btn btn-success mx-1">
                                Zapisz zmiany
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row justify-content-center m-2">
        <div class="col-xl-10 col-md-12 p-0">
            <div class="card border-primary " >
                <div class="card-body p-2 p-sm-3">                   
                    <div class="container">
                        <div class="row my-3">
                            <div class="col-md-9">
                                <h5 class="card-title mt-2"><?php echo e(__('Twoje adresy email')); ?></h5>
                            </div>
                            <div class="col-md-3">
                            <?php if($addNewMail == false): ?>
                                <button wire:click="$set('addNewMail', true)" type="button" class="btn btn-outline-primary btn-block">
                                    Dodaj adres email
                                </button>
                            <?php endif; ?>
                            </div>
                        </div>
                        <?php if($addNewMail): ?>
                        <div class="row my-3">
                            <div class="col-md-4">
                                <input id="newMail" wire:model="newMail" type="text" class="form-control" placeholder="Nowy adres email">
                                <?php $__errorArgs = ['newMail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class="form-text text-danger">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>                            
                            <div class="col-md-4 offset-md-4">
                                <div class="btn-group btn-block" role="group">
                                    <button wire:click="cancelSaveNewEmail" type="button" class="btn btn-outline-danger">
                                        Anuluj
                                    </button>
                                    <button wire:click="saveNewEmail" type="button" class="btn btn-success">
                                        Zapisz
                                    </button>
                                </div>  
                            </div>
                        </div>
                        <div>
                            <hr/>
                        </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $emailAdress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row my-2">
                            <div class="col-md-3">
                                <?php if($editEmail == $email['id']): ?>
                                    <input wire:model="editedEmail" type="text" class="form-control" placeholder="Adres email">
                                <?php else: ?>
                                <h6><?php echo e($email['email']); ?></h6>                                
                                <div class="custom-control custom-switch">
                                    <input wire:model="emailAdress.<?php echo e($index); ?>.enable" type="checkbox" class="custom-control-input" id="cus<?php echo e($index); ?>" checked="">
                                    <label class="custom-control-label" for="cus<?php echo e($index); ?>">Aktywny</label>
                                </div>
                                <?php endif; ?>
                                
                            </div>
                            <div class="col-md-6">
                                <div class="container my-2">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="custom-control custom-checkbox mx-2">
                                            <?php if( $emailAdress[$index]['enable'] ): ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.parts_notifications" type="checkbox" class="custom-control-input" id="cch1<?php echo e($index); ?>" >
                                            <?php else: ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.parts_notifications" type="checkbox" class="custom-control-input" id="cch1<?php echo e($index); ?>" disabled="disabled" >
                                            <?php endif; ?>
                                                <label class="custom-control-label" for="cch1<?php echo e($index); ?>">Części</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="custom-control custom-checkbox mx-2">
                                            <?php if( $emailAdress[$index]['enable'] ): ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.overviews_notifications" type="checkbox" class="custom-control-input" id="cch2<?php echo e($index); ?>" >
                                            <?php else: ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.overviews_notifications" type="checkbox" class="custom-control-input" id="cch2<?php echo e($index); ?>" disabled="disabled" >
                                            <?php endif; ?>
                                                <label class="custom-control-label" for="cch2<?php echo e($index); ?>">Przeglądy</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="custom-control custom-checkbox mx-2">
                                            <?php if( $emailAdress[$index]['enable'] ): ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.insurances_notifications" type="checkbox" class="custom-control-input" id="cch3<?php echo e($index); ?>" >
                                            <?php else: ?>
                                                <input wire:model="emailAdress.<?php echo e($index); ?>.insurances_notifications" type="checkbox" class="custom-control-input" id="cch3<?php echo e($index); ?>" disabled="disabled" >
                                            <?php endif; ?>
                                                <label class="custom-control-label" for="cch3<?php echo e($index); ?>">Ubezpieczenia</label>
                                            </div>
                                        </div>
                                    </div>            
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="btn-group btn-block" role="group" id="1">
                                <?php if($editEmail != $email['id']): ?>
                                    <?php if($ifDeleteEmail != $email['id']): ?>
                                    
                                        <button wire:click="setEditEmail(<?php echo e($email['id']); ?>)" type="button" class="btn btn-outline-primary">
                                            Edytuj
                                        </button>
                                        <button wire:click="setDeleteEmail(<?php echo e($email['id']); ?>)" type="button" class="btn btn-danger">
                                            Usuń
                                        </button>
                                    <?php elseif($ifDeleteEmail == $email['id']): ?>
                                        <button id="3" type="button" wire:click="confirmDeleteEmail" class="btn btn-outline-danger">
                                            Usuń
                                        </button>
                                        <button type="button" wire:click="cancelDeleteEmail" class="btn btn-success">
                                            Anuluj
                                        </button>                               
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button wire:click="cancelEditEmail" type="button" class="btn btn-outline-primary">
                                        Anuluj
                                    </button>
                                    <button wire:click="saveEditEmail" type="button" class="btn btn-success">
                                        Zapisz
                                    </button>
                                <?php endif; ?>
                                </div>                             
                            </div>
                        </div>
                        <div>
                            <hr/>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row my-3 justify-content-end mr-md-3 mr-0">
                            <button wire:click="saveEmailsRuleChanges" type="button" class="btn btn-success mx-1">
                                Zapisz zmiany
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\htdocs\inz\resources\views/livewire/notification-settings.blade.php ENDPATH**/ ?>