<div>
    <?php if($ifAddElement == false): ?>
    <div class="row justify-content-between">
        <?php if($ifAddWorkTimeHistory == false): ?>
            <div class="col-md-4 my-1">
            <?php if($workTimeUnit != 1): ?>                
                <button wire:click="$set('ifAddWorkTimeHistory', true)"class="btn btn-success btn-block" type="button">
                    Aktualizuj przebieg
                </button>
            <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="col-md-8 my-1">  
                <div class="container p-0 m-0">
                    <div class="row">
                        <div class="col-md-3">
                            Aktualny przebieg
                        </div>
                        <div class="col-md-4 my-1">
                            <input id="currentWorkTimeValue" 
                                wire:model="currentWorkTimeValue" 
                                wire:keydown.enter="storeNewWorkTimeHistory"
                                type="number" class="form-control" 
                                min="<?php echo e($oldWorkTimeValue); ?>" step="1">  
                            <?php $__errorArgs = ['currentWorkTimeValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="form-text text-danger">
                                    <?php echo e($message); ?>

                                </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-5 my-1">
                            <div class="btn-group btn-block" role="group">
                                <button wire:click="$set('ifAddWorkTimeHistory', false)" type="button" class="btn btn-outline-primary">Anuluj</button>
                                <button wire:click="storeNewWorkTimeHistory" type="button" class="btn btn-success">Zapisz</button>
                            </div>
                        </div>
                    </div>
                </div>        
            </div>
        <?php endif; ?>
        <div class="col-md-4 my-1">
            <button wire:click="$set('ifAddElement', true)" class="btn btn-primary btn-block" type="button">
                Dodaj informacje
            </button>
        </div>
    </div>
    <?php else: ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-new-element', ['object_id' => $object->id])->html();
} elseif ($_instance->childHasBeenRendered('NOMK3tz')) {
    $componentId = $_instance->getRenderedChildComponentId('NOMK3tz');
    $componentTag = $_instance->getRenderedChildComponentTagName('NOMK3tz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NOMK3tz');
} else {
    $response = \Livewire\Livewire::mount('add-new-element', ['object_id' => $object->id]);
    $html = $response->html();
    $_instance->logRenderedChild('NOMK3tz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>    
    </div>
    <?php endif; ?>
        <div class="accordion mt-3" id="accordionExample">  
        <?php if(count($parts) > 0): ?>      
            <div class="card">
                <div class="card-header p-1 " id="1">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="1">
                        <img src="<?php echo e(asset('storage/svg/part.svg')); ?>" width="30" height="30" alt="" class="float-left mr-3">
                            Części
                            <?php if(isset($events[1])): ?>
                            <span class="text-danger float-right">
                                <strong>Zbliżają się zdarzenia!</strong>
                            </span>
                            <?php endif; ?>
                        </button>
                    </h2>
                </div>
                <div id="collapse1" class="collapse hide" aria-labelledby="1" data-parent="#accordionExample">
                    <div class="card-body p-2">
                        <div class="container px-2">
                        <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php if(!$loop->first): ?>  
                            <div>
                                <hr class="m-0" />
                            </div>
                            <?php endif; ?>                          
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-element', ['element_id' => $part->id])->html();
} elseif ($_instance->childHasBeenRendered($part->id)) {
    $componentId = $_instance->getRenderedChildComponentId($part->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($part->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($part->id);
} else {
    $response = \Livewire\Livewire::mount('display-element', ['element_id' => $part->id]);
    $html = $response->html();
    $_instance->logRenderedChild($part->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                                                 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>                  
                    </div>
                </div>
            </div>        
        <?php endif; ?>
        <?php if(count($overviews) > 0): ?>      
            <div class="card">
                <div class="card-header p-1 " id="2">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="2">
                        <img src="<?php echo e(asset('storage/svg/overview.svg')); ?>" width="30" height="30" alt="" class="float-left mr-3">
                            Przeglądy
                            <?php if(isset($events[2])): ?>
                            <span class="text-danger float-right">
                                <strong>Zbliżają się zdarzenia!</strong>
                            </span>
                            <?php endif; ?>
                        </button>
                    </h2>
                </div>
                <div id="collapse2" class="collapse hide" aria-labelledby="2" data-parent="#accordionExample">
                    <div class="card-body p-2">
                        <div class="container px-2">
                        <?php $__currentLoopData = $overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php if(!$loop->first): ?>  
                            <div>
                                <hr class="m-0" />
                            </div>
                            <?php endif; ?>                          
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-element', ['element_id' => $overview->id])->html();
} elseif ($_instance->childHasBeenRendered($overview->id)) {
    $componentId = $_instance->getRenderedChildComponentId($overview->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($overview->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($overview->id);
} else {
    $response = \Livewire\Livewire::mount('display-element', ['element_id' => $overview->id]);
    $html = $response->html();
    $_instance->logRenderedChild($overview->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                                                 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>                  
                    </div>
                </div>
            </div>        
        <?php endif; ?>
        <?php if(count($insurances) > 0): ?>      
            <div class="card">
                <div class="card-header p-1 " id="3">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="3">
                        <img src="<?php echo e(asset('storage/svg/insurance.svg')); ?>" width="30" height="30" alt="" class="float-left mr-3">
                            Ubezpieczenia
                            <?php if(isset($events[3])): ?>
                            <span class="text-danger float-right">
                                <strong>Zbliżają się zdarzenia!</strong>
                            </span>
                            <?php endif; ?>
                        </button>
                    </h2>
                </div>
                <div id="collapse3" class="collapse hide" aria-labelledby="3" data-parent="#accordionExample">
                    <div class="card-body p-2">
                        <div class="container px-2">
                        <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php if(!$loop->first): ?>  
                            <div>
                                <hr class="m-0" />
                            </div>
                            <?php endif; ?>                          
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-element', ['element_id' => $insurance->id])->html();
} elseif ($_instance->childHasBeenRendered($insurance->id)) {
    $componentId = $_instance->getRenderedChildComponentId($insurance->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($insurance->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($insurance->id);
} else {
    $response = \Livewire\Livewire::mount('display-element', ['element_id' => $insurance->id]);
    $html = $response->html();
    $_instance->logRenderedChild($insurance->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                                                 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>                  
                    </div>
                </div>
            </div>        
        <?php endif; ?>
        </div>
        
</div>

<?php /**PATH C:\htdocs\inz\resources\views/livewire/display-elements.blade.php ENDPATH**/ ?>