<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 0])->html();
} elseif ($_instance->childHasBeenRendered('19371Ld')) {
    $componentId = $_instance->getRenderedChildComponentId('19371Ld');
    $componentTag = $_instance->getRenderedChildComponentTagName('19371Ld');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('19371Ld');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('19371Ld', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <div class="row justify-content-center mt-md-5 mt-3 m-2">
        <div class="col-xl-8 col-md-10 p-0">
            <div class="card border-primary " >
                <div class="card-body">                   
                    <div class="container-xl py-3">
                        <div class="row">
                            <div class="col-9">
                                <h4 class="card-title mb-3 mt-2">Edycja <?php echo e($object_name); ?></h4>
                            </div>
                            <div class="col-3 float-right">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn close " aria-label="Close">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="floatName"><?php echo e(__('object.vehicle.create.name')); ?></label> 
                                <input id="floatName" type="text" name="object_name" class="form-control"
                                    value="<?php echo e(old('object_name')); ?>" required wire:model="object_name" placeholder="wprowadź własną nazwę">                               
                            </div>
                            <?php $__errorArgs = ['object_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="form-text text-danger">
                                    <?php echo e($message); ?>

                                </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group col-md-6">
                                <label for="unit"><?php echo e(__('Jednostka czasu pracy')); ?></label>
                                <select name="object_unit"
                                        wire:model.lazy="selectedWorkTimeUnit"
                                        class="form-control" required >
                                    <?php $__currentLoopData = $allWorkTimeUnit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>" >
                                            <?php echo e($unit->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['selectedWorkTimeUnit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="form-text text-danger">
                                    <?php echo e($message); ?>

                                </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <hr/>
                        </div>
                        <div class="row mt-4">
                            <div class="col">
                                <p class="lead">Szczegóły</p>
                            </div>
                        </div>
                        <div class="container m-0 p-0">
                            <?php $__currentLoopData = $addDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $addDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row py-1">
                                <div class="col-sm-4 my-1">
                                    <select name="addDetails[<?php echo e($index); ?>][detail_typeable_id]"
                                            wire:model.lazy="addDetails.<?php echo e($index); ?>.detail_typeable_id"
                                            class="form-control" >
                                        <option value=""><?php echo e(__('object.vehicle.create.choose_type')); ?></option>
                                        <?php $__currentLoopData = $allDetailsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($detailType->id); ?>">
                                                <?php echo e($detailType->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-6 my-1">
                                    <input type="text"
                                        name="addDetails[<?php echo e($index); ?>][value]"
                                        class="form-control"
                                        placeholder="<?php echo e(__('object.vehicle.create.put_value')); ?>"
                                        wire:model="addDetails.<?php echo e($index); ?>.value" />
                                </div>
                                
                                <div class="col-sm-2 justify-content-end my-1">
                                    <button type="button" class="btn btn-sm btn-danger px-3 pb-2 float-right" wire:click.prevent="removeDetail(<?php echo e($index); ?>)"><?php echo e(__('object.buttons.delete')); ?></button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row justify-content-start">
                                <div class="col-sm-6 offset-md-4 my-2 justify-content-end">
                                    <button class="btn btn btn-outline-primary btn-block px-3"
                                        wire:click.prevent="addDetail"><?php echo e(__('object.buttons.add_detail')); ?></button>
                                </div>
                            </div>
                        
                        </div>  
                        <div>
                            <hr/>
                        </div>
                        <div class="row mt-4">
                            <div class="col">
                                <p class="lead">Własne szczegóły</p>
                            </div>
                        </div>
                        <div class="container m-0 p-0">
                                <?php $__currentLoopData = $addOwnDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $addDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row py-1">
                                    <div class="col-sm-4 my-1">
                                        <input type="text"
                                            name="addOwnDetails[<?php echo e($index); ?>][own_name]"
                                            class="form-control"
                                            placeholder="<?php echo e(__('wpisz nazwę')); ?>"
                                            wire:model="addOwnDetails.<?php echo e($index); ?>.own_name" />
                                    </div>
                                    <div class="col-sm-6 my-1">
                                        <input type="text"
                                            name="addOwnDetails[<?php echo e($index); ?>][value]"
                                            class="form-control"
                                            placeholder="<?php echo e(__('wpisz wartość')); ?>"
                                            wire:model="addOwnDetails.<?php echo e($index); ?>.value" />
                                    </div>
                                    
                                    <div class="col-sm-2 justify-content-end my-1">
                                        <button type="button" class="btn btn-sm btn-danger px-3 pb-2 float-right" wire:click.prevent="removeOwnDetail(<?php echo e($index); ?>)"><?php echo e(__('object.buttons.delete')); ?></button>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row justify-content-start">
                                    <div class="col-sm-6 offset-md-4 my-2 justify-content-end">
                                        <button class="btn btn btn-outline-primary btn-block px-3"
                                            wire:click.prevent="addOwnDetail"><?php echo e(__('object.buttons.add_own_detail')); ?></button>
                                    </div>
                                </div>
                            
                        </div> 
                        <div class="row mt-5">
                            <div class="col-md-6 my-1">
                                <button wire:click="saveAll" type="button" class="btn btn-success btn-block pt-2">
                                    <h5>Zapisz zmiany</h5>
                                </button>
                            </div>
                            <div class="col-md-6 my-1">
                                <a href="<?php echo e(url()->previous()); ?>" type="button" class="btn btn-outline-danger btn-block pt-2">
                                    <h5>Anuluj</h5>
                                </a>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>
<?php /**PATH C:\htdocs\inz\resources\views/livewire/edit-object.blade.php ENDPATH**/ ?>