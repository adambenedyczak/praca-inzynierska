<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="alert alert-warning" role="alert">
                <h4 class="alert-heading">Potrzebna weryfikacja adresu email!</h4>
                <?php if(session('resent')): ?>
                    <p>Nowy link weryfikacyjny został wysłany na Twój adres email!</p>
                <?php endif; ?>
                <p>Zanim przejdziesz dalej, sprawdź skrzynkę odbiorczą i kliknij w link weryfikacyjny.</p>
                <hr>
                Jeżeli nie otrzymałeś wiadomości,   
                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><strong><?php echo e(__('kliknij w ten link')); ?></strong></button>.
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/auth/verify.blade.php ENDPATH**/ ?>