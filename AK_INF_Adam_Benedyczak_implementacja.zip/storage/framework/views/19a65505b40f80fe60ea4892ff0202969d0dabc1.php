

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 1])->html();
} elseif ($_instance->childHasBeenRendered('AxctFmN')) {
    $componentId = $_instance->getRenderedChildComponentId('AxctFmN');
    $componentTag = $_instance->getRenderedChildComponentTagName('AxctFmN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AxctFmN');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 1]);
    $html = $response->html();
    $_instance->logRenderedChild('AxctFmN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php if( count($vehicles) > 0): ?>
    <div class="mt-md-5 mt-3">
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center">
            <div class="col-xl-8 col-md-10">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object', ['object_id' => $vehicle->id])->html();
} elseif ($_instance->childHasBeenRendered('pB3eeHU')) {
    $componentId = $_instance->getRenderedChildComponentId('pB3eeHU');
    $componentTag = $_instance->getRenderedChildComponentTagName('pB3eeHU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pB3eeHU');
} else {
    $response = \Livewire\Livewire::mount('display-object', ['object_id' => $vehicle->id]);
    $html = $response->html();
    $_instance->logRenderedChild('pB3eeHU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/vehicles/index.blade.php ENDPATH**/ ?>