

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar')->html();
} elseif ($_instance->childHasBeenRendered('lOC4sUl')) {
    $componentId = $_instance->getRenderedChildComponentId('lOC4sUl');
    $componentTag = $_instance->getRenderedChildComponentTagName('lOC4sUl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lOC4sUl');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar');
    $html = $response->html();
    $_instance->logRenderedChild('lOC4sUl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php if($mustVerify == true): ?>
    <div class="mt-md-5 mt-3">  
        <div class="row justify-content-center">
            <div class="col-xl-8 col-md-10">
                <div class="jumbotron bg-primary text-white">
                    <h1 class="mb-4">Witaj, <?php echo e($user->name); ?>!</h1>
                    <p class="lead">Dziękujemy za dołączenie do grona użytkowników <?php echo e(config('app.name', 'Laravel')); ?>. </br>Cieszymy się, że jesteś z nami!</p>
                    <hr class="my-4">
                    <p class="lead">Na podany przez Ciebie adres email został wysłany link weryfikacyjny. 
                    </br>Proszę, kliknij w niego aby korzystać w pełni z możliwości serwisu.
                    </br></br>Jeżeli nie otrzymałeś(-aś) wiadomości,   
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn text-white p-0 m-0 align-baseline"><strong><?php echo e(__('kliknij w ten link')); ?></strong></button>.
                    </form>
                    </p>
                </div>
            </div>
        </div>
    </div>

<?php else: ?>
    <?php if( count($favs) > 0): ?>
        <div class="mt-md-5 mt-3">
            <?php $__currentLoopData = $favs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row justify-content-center">
                <div class="col-xl-8 col-md-10">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object', ['object_id' => $fav->id])->html();
} elseif ($_instance->childHasBeenRendered('23bkoX5')) {
    $componentId = $_instance->getRenderedChildComponentId('23bkoX5');
    $componentTag = $_instance->getRenderedChildComponentTagName('23bkoX5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('23bkoX5');
} else {
    $response = \Livewire\Livewire::mount('display-object', ['object_id' => $fav->id]);
    $html = $response->html();
    $_instance->logRenderedChild('23bkoX5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
    <div class="mt-md-5 mt-3">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-md-10">
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Twoja lista ulubionych jest pusta!</strong> 
                    <p>
                        Zaznacz ikonę gwiazdki przy Twoim pojeździe, przyczepie lub agregacie, 
                        aby widzieć go na stronie głównej.
                    </p>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/dashboard.blade.php ENDPATH**/ ?>