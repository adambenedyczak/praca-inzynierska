

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 2])->html();
} elseif ($_instance->childHasBeenRendered('BcA8D0K')) {
    $componentId = $_instance->getRenderedChildComponentId('BcA8D0K');
    $componentTag = $_instance->getRenderedChildComponentTagName('BcA8D0K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BcA8D0K');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 2]);
    $html = $response->html();
    $_instance->logRenderedChild('BcA8D0K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php if( count($trailers) > 0): ?>
    <div class="mt-md-5 mt-3">
        <?php $__currentLoopData = $trailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center">
            <div class="col-xl-8 col-md-10">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object', ['object_id' => $trailer->id])->html();
} elseif ($_instance->childHasBeenRendered('QZ3X3D6')) {
    $componentId = $_instance->getRenderedChildComponentId('QZ3X3D6');
    $componentTag = $_instance->getRenderedChildComponentTagName('QZ3X3D6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QZ3X3D6');
} else {
    $response = \Livewire\Livewire::mount('display-object', ['object_id' => $trailer->id]);
    $html = $response->html();
    $_instance->logRenderedChild('QZ3X3D6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/trailers/index.blade.php ENDPATH**/ ?>