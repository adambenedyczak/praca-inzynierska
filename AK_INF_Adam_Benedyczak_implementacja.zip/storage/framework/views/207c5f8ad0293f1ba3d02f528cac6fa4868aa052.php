

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 3])->html();
} elseif ($_instance->childHasBeenRendered('b4caFDd')) {
    $componentId = $_instance->getRenderedChildComponentId('b4caFDd');
    $componentTag = $_instance->getRenderedChildComponentTagName('b4caFDd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('b4caFDd');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 3]);
    $html = $response->html();
    $_instance->logRenderedChild('b4caFDd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php if( count($machines) > 0): ?>
    <div class="mt-md-5 mt-3">
        <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center">
            <div class="col-xl-8 col-md-10">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object', ['object_id' => $machine->id])->html();
} elseif ($_instance->childHasBeenRendered('QtZk2M1')) {
    $componentId = $_instance->getRenderedChildComponentId('QtZk2M1');
    $componentTag = $_instance->getRenderedChildComponentTagName('QtZk2M1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QtZk2M1');
} else {
    $response = \Livewire\Livewire::mount('display-object', ['object_id' => $machine->id]);
    $html = $response->html();
    $_instance->logRenderedChild('QtZk2M1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/machines/index.blade.php ENDPATH**/ ?>