<div>
    <div class="row justify-content-center m-2">
        <div class="col-12 p-0">
            <div class="card border-primary" >
                <div class="card-body p-2">                   
                    <div class="container-xl py-3">
                        <div class="row">
                            <div class="col-10">
                                <h5 class="card-title mb-1"><?php echo e(__('Nowa informacja')); ?></h5>
                            </div>
                            <div class="col-2 float-left">
                                <button wire:click="cancelAdd" type="button" class="close" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 ">
                                <span class="lead"> Wybierz, co chcesz dodać</span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <?php $__currentLoopData = $elementCategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4 text-center my-1">
                                <?php if($selectedCategory == $category->id): ?>
                                    <button wire:click="$set('selectedCategory', <?php echo e($category->id); ?>)" type="button" class="btn btn-primary btn-block" >
                                <?php else: ?>
                                    <button wire:click="$set('selectedCategory', <?php echo e($category->id); ?>)" type="button" class="btn btn-outline-primary btn-block" >
                                <?php endif; ?>
                                        <h6><?php echo e($category->name); ?></h6>
                                    </button>                        
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating my-1">
                                    <label for="unit"><?php echo e(__('Kategoria')); ?></label>
                                    <select name="selectedType"
                                            wire:model.lazy="selectedType"
                                            class="form-control" required >
                                        <option value=""><?php echo e(__('wybierz')); ?></option>
                                        <?php $__currentLoopData = $allType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type->id); ?>" >
                                                <?php echo e($type->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['selectedType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class="form-text text-danger">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 my-1">
                                <div class="form-floating">
                                    <label for="floatName"><?php echo e(__('Nazwa')); ?></label> 
                                    <input id="floatName" type="text" name="element_name" class="form-control"
                                        value="<?php echo e(old('element_name')); ?>" required wire:model="element_name" placeholder="wprowadź nazwę">                               
                                </div>
                                <?php $__errorArgs = ['element_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class="form-text text-danger">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                            </div>
                        </div>
                        <div>
                            <hr/>
                        </div>
                        <div class="row mt-2">
                            <div class="col-12">
                                <div class="custom-control custom-switch">
                                    <input wire:model="addEvent" type="checkbox" class="custom-control-input" id="customSwitch1" >
                                    <label class="custom-control-label pl-2" for="customSwitch1">Dodaj zdarzenie</label>
                                </div>
                            </div>
                        </div>
                        <?php if($addEvent): ?>
                        <div class="row">
                            <div class="col-12">
                                <span class="lead"> Termin ważności (następnej wymiany)</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating my-1">
                                    <label for="nextDate"><?php echo e(__('Data')); ?></label>
                                    <input type="date" name="nextDate" min="<?php echo e($tomorrow); ?>"
                                            wire:model="nextDate"
                                            class="form-control" required 
                                            placeholder="dd-mm-rrrr"
                                            pattern="">
                                    </input>
                                </div>
                                <?php $__errorArgs = ['nextDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class="form-text text-danger">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($object->work_time_unit_id > 1): ?>
                            <div class="col-md-6 my-1">
                                <div class="form-floading">
                                    <label for="nextWorkTimeValue"><?php echo e(__('Przebieg')); ?></label> 
                                    <input id="nextWorkTimeValue" type="number" name="nextWorkTimeValue" class="form-control"
                                        value="<?php echo e(old('element_name')); ?>" required 
                                        wire:model="nextWorkTimeValue" placeholder="wprowadź przebieg"
                                        min="<?php echo e($workTimeValue); ?>" step="1">                               
                                </div>
                                <?php $__errorArgs = ['nextWorkTimeValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <small class="form-text text-danger">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div>
                            <hr/>
                        </div>
                        <div class="row">
                            <div class="col">
                                <p class="lead m-0">Szczegóły</p>
                            </div>
                        </div>
                        <div class="container m-0 p-0">
                                <?php $__currentLoopData = $addOwnDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $addDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row py-1">
                                    <div class="col-sm-4 my-1">
                                        <input type="text"
                                            name="addOwnDetails[<?php echo e($index); ?>][own_name]"
                                            class="form-control"
                                            placeholder="<?php echo e(__('wpisz nazwę')); ?>"
                                            wire:model="addOwnDetails.<?php echo e($index); ?>.own_name" />
                                    </div>
                                    <div class="col-sm-6 my-1">
                                        <input type="text"
                                            name="addOwnDetails[<?php echo e($index); ?>][value]"
                                            class="form-control"
                                            placeholder="<?php echo e(__('wpisz wartość')); ?>"
                                            wire:model="addOwnDetails.<?php echo e($index); ?>.value" />
                                    </div>
                                    
                                    <div class="col-sm-2 justify-content-end my-1">
                                        <button type="button" class="btn btn-sm btn-danger px-3 pb-2 float-right" wire:click.prevent="removeOwnDetail(<?php echo e($index); ?>)"><?php echo e(__('object.buttons.delete')); ?></button>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row justify-content-start">
                                    <div class="col-sm-6 offset-md-4 my-2 justify-content-end">
                                        <button class="btn btn btn-outline-primary btn-block px-3"
                                            wire:click.prevent="addOwnDetail">Dodaj szczegół</button>
                                    </div>
                                </div>
                            
                        </div> 
                        <div class="row mt-3">
                            <div class="col">
                                <button wire:click="saveAll" type="button" class="btn btn-success btn-block pt-2 pb-1">
                                    <h5>Zapisz</h5>
                                </button>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>
<?php /**PATH C:\htdocs\inz\resources\views/livewire/add-new-element.blade.php ENDPATH**/ ?>