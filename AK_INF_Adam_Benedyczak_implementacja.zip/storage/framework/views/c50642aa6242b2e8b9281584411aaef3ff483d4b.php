<div>
    <div class="row my-2 align-items-center">
        <?php if($action != 2): ?>
            <div class="col-md-3">
                <span class="lead"><?php echo e($element->elements_typeable->name); ?></span>
            </div>
            <div class="col-md-3">
                <strong><?php echo e($element->name); ?></strong>
            </div>
            <div class="col-md-3 pt-2 pt-md-0">
            <?php if( $event): ?>
                <span class="text-primary">
                <?php echo e(date("d-m-Y", strtotime($event->expired_date))); ?> 
                </span>
                <?php if( $event->work_time_value  ): ?>
                    <div class="text-muted">
                    <?php echo e(number_format($event->work_time_value,0,""," ")); ?> <?php echo e($object->work_time_unit->short); ?>

                    </div>
                <?php endif; ?>
            <?php endif; ?>
            </div>        
            <div class="col-md-3">
                <div class="float-right">
                    <?php if($ifMore == false): ?>
                    <button type="button" wire:click="$set('ifMore', true)" class="btn <?php if($this->alert): ?> btn-warning <?php endif; ?> btn-outline-primary btn-block">
                    Więcej
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-expand" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M3.646 9.146a.5.5 0 0 1 .708 0L8 12.793l3.646-3.647a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 0-.708zm0-2.292a.5.5 0 0 0 .708 0L8 3.207l3.646 3.647a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 0 0 0 .708z"/>
                        </svg>
                    </button>
                    <?php else: ?>
                    <button type="button" wire:click="$set('ifMore', false)" class="btn btn-outline-primary btn-block">
                    Mniej
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-contract" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M3.646 13.854a.5.5 0 0 0 .708 0L8 10.207l3.646 3.647a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 0 0 0 .708zm0-11.708a.5.5 0 0 1 .708 0L8 5.793l3.646-3.647a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 0-.708z"/>
                        </svg>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif($action == 2): ?>
            <div class="col-md-4">
                <label for="selectedType"><?php echo e(__('Kategoria')); ?></label>
                    <select name="selectedType"
                            wire:model.lazy="selectedType"
                            class="form-control" required >
                        <option value=""><?php echo e(__('wybierz')); ?></option>
                        <?php $__currentLoopData = $allType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>" >
                                <?php echo e($type->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php $__errorArgs = ['selectedType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-5">
                <div class="form-floating">
                    <label for="floatName"><?php echo e(__('Nazwa')); ?></label> 
                    <input id="floatName" type="text" name="element_name" class="form-control"
                        value="<?php echo e(old('element_name')); ?>" required wire:model="element_name" placeholder="wprowadź nazwę">                               
                </div>
                <?php $__errorArgs = ['element_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <div class="col-md-3">
                <div class="float-right ">
                    <?php if($ifMore == false): ?>
                    <button type="button" wire:click="$set('ifMore', true)" class="btn btn-outline-primary btn-block">
                    Więcej
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-expand" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M3.646 9.146a.5.5 0 0 1 .708 0L8 12.793l3.646-3.647a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 0-.708zm0-2.292a.5.5 0 0 0 .708 0L8 3.207l3.646 3.647a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 0 0 0 .708z"/>
                        </svg>
                    </button>
                    <?php else: ?>
                    <button type="button" wire:click="$set('ifMore', false)" class="btn btn-outline-primary btn-block">
                    Mniej
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-contract" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M3.646 13.854a.5.5 0 0 0 .708 0L8 10.207l3.646 3.647a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 0 0 0 .708zm0-11.708a.5.5 0 0 1 .708 0L8 5.793l3.646-3.647a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 0-.708z"/>
                        </svg>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if($action == 2 ): ?>
    <div class="row mt-2">
        <div class="col-12">
            <div class="custom-control custom-switch">
                <input wire:model="isSetEvent" type="checkbox" class="custom-control-input" id="customSwitch1" >
                <label class="custom-control-label pl-2" for="customSwitch1">Edytuj zdarzenie</label>
            </div>
        </div>
    </div>
    <?php if($isSetEvent == true ): ?>
        <div class="row">
            <div class="col-12">
                <span class="lead"> Termin ważności/następnej wymiany</span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-floating my-1">
                    <label for="nextDate"><?php echo e(__('Data')); ?></label>
                    <input type="date" name="nextDate" min="<?php echo e($tomorrow); ?>"
                            wire:model="nextDate"
                            class="form-control" required >
                    </input>
                </div>
                <?php $__errorArgs = ['nextDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if($object->work_time_unit_id > 1): ?>
            <div class="col-md-6 my-1">
                <div class="form-floading">
                    <label for="nextWorkTimeValue"><?php echo e(__('Przebieg')); ?></label> 
                    <input id="nextWorkTimeValue" type="number" name="nextWorkTimeValue" class="form-control"
                        value="<?php echo e(old('element_name')); ?>" required 
                        wire:model="nextWorkTimeValue" placeholder="wprowadź przebieg"
                        min="<?php echo e($workTimeValue); ?>" step="1">                               
                </div>
                <?php $__errorArgs = ['nextWorkTimeValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
            </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <div>
        <hr/>
    </div>
    <?php endif; ?>
    <?php if($ifMore == true): ?>
        <?php if($action != 2): ?>
        <div class="row mb-2">
            <?php $__currentLoopData = $ownDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailCol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 ">
                <div class="container">
                    <?php $__currentLoopData = $detailCol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-5 text-muted">
                            <?php echo e($detail['own_name']); ?>: 
                        </div>
                        <div class="col-7" >
                            <?php echo e($detail['value']); ?>

                        </div>
                    </div>                                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <?php $__currentLoopData = $ownDetailsEdit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row my-1">
                <div class="col-sm-4 my-1">
                    <input type="text" name="ownDetailsEdit[<?php echo e($index); ?>][own_name]" 
                        wire:model="ownDetailsEdit.<?php echo e($index); ?>.own_name" 
                        class="form-control" placeholder="nazwa"> 
                </div>
                <div class="col-sm-6 my-1" >
                    <input type="text" name="ownDetailsEdit[<?php echo e($index); ?>][value]" 
                        wire:model="ownDetailsEdit.<?php echo e($index); ?>.value" 
                        class="form-control" placeholder="wartość">
                </div>
                <div class="col-sm-2 my-1">
                    <button type="button" wire:click.prevent="removeElementDetail(<?php echo e($index); ?>)" 
                            class="btn btn-danger btn-block">Usuń</button>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="row justify-content-start">
                <div class="col-md-4 my-2">
                    <button class="btn btn btn-primary btn-block px-3"
                        wire:click.prevent="addElementDetail">Dodaj szczegół</button>
                </div>
                <div class="col-md-8 my-2">
                    <div class="btn-group btn-block" role="group" id="ab3">
                        <button wire:click="cancelSave" type="button" class="btn btn-outline-primary">Anuluj</button>
                        <button wire:click="saveAll" type="button" class="btn btn-success">Zapisz</button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($action != 1): ?>
        <div class="row justify-content-end mb-2">
            <div class="col-12 col-md-6">
                <?php if($action == 0): ?>
                <div class="btn-group btn-block" role="group" id="1">
                    <?php if($isSetEvent): ?>
                        <button wire:click="updateEvent" type="button" class="btn btn-success">Aktualizuj</button>
                    <?php else: ?>
                        <button wire:click="updateEvent" type="button" class="btn btn-success" disabled>Aktualizuj</button>
                    <?php endif; ?>
                    <?php if(count($allEventsPast) > 0): ?>
                        <button wire:click="showHistory" type="button" class="btn btn-outline-info">Historia</button>
                    <?php else: ?>
                        <button wire:click="showHistory" type="button" class="btn btn-outline-info" disabled>Historia</button>
                    <?php endif; ?>
                    <button wire:click="$set('action', 2)"type="button" class="btn btn-outline-primary">Edytuj</button>
                    <button wire:click="setDelete" type="button" class="btn btn-outline-danger">Usuń</button>
                </div>
                <?php elseif($action == 3): ?>
                <div class="btn-group btn-block" role="group" id="2">
                    <button type="button" wire:click="confirmDeleteElement" class="btn btn-outline-danger">Usuń</button>
                    <button type="button" wire:click="cancelDeleteElement" class="btn btn-success">Anuluj</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div>
            <hr/>
        </div>
        <div class="row">
            <div class="col-md-3">
                Wykonana wymiana
            </div>
            <div class="col-md-3">
                <div class="form-floating my-1">
                    <input type="date" name="doneDate" min="<?php echo e($tomorrow); ?>"
                            wire:model="doneDate"
                            class="form-control" required>
                    </input>
                </div>
                <?php $__errorArgs = ['doneDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3 my-1">
            <?php if($object->work_time_unit_id > 1): ?>            
                <div class="form-floading">
                    <input id="doneWorkTimeValue" type="number" name="doneWorkTimeValue" class="form-control"
                        value="<?php echo e(old('doneWorkTimeValue')); ?>" required 
                        wire:model="doneWorkTimeValue" placeholder="wprowadź przebieg"
                        min="<?php echo e($workTimeValue); ?>" step="1">                               
                </div>
                <?php $__errorArgs = ['doneWorkTimeValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
            <?php endif; ?>
            </div>           
        </div>
        <div class="row my-1">
            <div class="col-md-3">
                Następna wymiana / termin ważności
            </div>
            <div class="col-md-3">
                <div class="form-floating my-1">
                    <input type="date" name="nextNextDate" min="<?php echo e($tomorrow); ?>"
                            wire:model="nextNextDate"
                            class="form-control" required>
                    </input>
                </div>
                <?php $__errorArgs = ['nextNextDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3 my-1">
            <?php if($object->work_time_unit_id > 1): ?>
            
                <div class="form-floading">
                    <input id="nextNextWorkTimeValue" type="number" name="nextNextWorkTimeValue" class="form-control"
                        value="<?php echo e(old('nextNextWorkTimeValue')); ?>" required 
                        wire:model="nextNextWorkTimeValue" placeholder="wprowadź przebieg"
                        min="<?php echo e($workTimeValue); ?>" step="1">                               
                </div>
                <?php $__errorArgs = ['nextNextWorkTimeValuee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <small class="form-text text-danger">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>              
            <?php endif; ?>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="btn-group btn-block" role="group" id="53">
                    <button wire:click="cancelNewEvent" type="button" class="btn btn-outline-primary">Anuluj</button>
                    <button wire:click="storeNewEvent" type="button" class="btn btn-success">Zapisz</button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>




    <!-- Modal -->
    <div class="modal fade" id="elementHistory<?php echo e($element_id); ?>" tabindex="-1" role="dialog" aria-labelledby="elementHistoryTitle<?php echo e($element_id); ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="elementHistoryTitle<?php echo e($element_id); ?>">Historia elementu: <?php echo e($element->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <?php $__currentLoopData = $allEventsPast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$loop->first): ?>
                                <div>
                                    <hr/>
                                </div>
                            <?php endif; ?>
                            <div class="row align-items-center">
                                <div class="col-md-3 text-muted">
                                    Wymiana:
                                </div>
                                <div class="col-md-3">
                                    <span class="float-right">
                                        <?php echo e(date("d-m-Y", strtotime($event->done_date))); ?> 
                                    </span>
                                </div>
                                <div class="col-md-3 text-muted">
                                    Przebieg:
                                </div>
                                <div class="col-md-3">
                                    <span class="float-right">
                                        <?php if($event->done_work_time_value != null): ?>
                                            <?php echo e(number_format($event->done_work_time_value,0,""," ")); ?> <?php echo e($object->work_time_unit->short); ?> 
                                        <?php else: ?>
                                            --
                                        <?php endif; ?> 
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Zamknij</button>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">

    window.livewire.on('show<?php echo e($element_id); ?>', () => {
        $('#elementHistory<?php echo e($element_id); ?>').modal('show');
    });

    </script>

</div>
<?php /**PATH C:\htdocs\inz\resources\views/livewire/display-element.blade.php ENDPATH**/ ?>