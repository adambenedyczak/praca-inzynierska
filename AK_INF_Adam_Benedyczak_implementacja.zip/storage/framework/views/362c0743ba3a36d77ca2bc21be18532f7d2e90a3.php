<?php echo e($slot); ?>

<?php /**PATH C:\htdocs\inz\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>