<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <!-- Styles -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet">

   

    <?php echo $__env->yieldContent('css-styles'); ?>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="d-flex" id="wrapper">
        
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.pagecontent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>    

    <!-- <script type="text/javascript" src="<?php echo e(url('js/app.js')); ?>"></script> -->
    <script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    


    <?php echo $__env->yieldContent('js-scripts'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


</body>


</html>
<?php /**PATH C:\htdocs\inz\resources\views/layouts/app.blade.php ENDPATH**/ ?>