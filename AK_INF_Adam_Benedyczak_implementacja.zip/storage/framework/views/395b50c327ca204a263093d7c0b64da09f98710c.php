<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
<div class="container">
    <?php if(auth()->guard()->check()): ?>      
        <button class="btn btn-primary" id="menu-toggle">
            <span class="navbar-toggler-icon"></span>
        </button>
    <?php endif; ?>
    <a class="navbar-brand ml-md-3 ml-sm-1 pt-2 d-none d-sm-block" href="<?php echo e(route('home')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>

        <?php if(auth()->guard()->check()): ?>
        <div class="ml-auto">
            <div class="dropdown float-left">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('notifications-bar')->html();
} elseif ($_instance->childHasBeenRendered('l5jiv4E')) {
    $componentId = $_instance->getRenderedChildComponentId('l5jiv4E');
    $componentTag = $_instance->getRenderedChildComponentTagName('l5jiv4E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l5jiv4E');
} else {
    $response = \Livewire\Livewire::mount('notifications-bar');
    $html = $response->html();
    $_instance->logRenderedChild('l5jiv4E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>

            
            <div class="dropdown  float-left">
                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-circle mr-1" viewBox="0 0 16 16">
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path>
                        <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"></path>
                    </svg>
                    <?php echo e(Auth::user()->name); ?>

                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    
                    <a class="dropdown-item" href="<?php echo e(route('notifications.settings')); ?>" >
                        <?php echo e(__('auth.btn_notif_set')); ?>

                    </a>

                    <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>" >
                        <?php echo e(__('auth.btn_edit_data')); ?>

                    </a>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <?php echo e(__('auth.btn_log_out')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
            </div>
        <?php endif; ?>
        </div>
</nav><?php /**PATH C:\htdocs\inz\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>