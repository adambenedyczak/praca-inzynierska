<div id="page-content-wrapper">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-xl mt-md-3 mt-xl-5 p-0">
        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-2 mt-3 pt-5 mb-4">
          <?php echo $__env->yieldContent('content'); ?>      
        </div>
    </div>
</div>

<?php $__env->startSection('js-scripts'); ?>
<script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>
  
<?php $__env->stopSection(); ?><?php /**PATH C:\htdocs\inz\resources\views/layouts/pagecontent.blade.php ENDPATH**/ ?>