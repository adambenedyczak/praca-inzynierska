

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 2])->html();
} elseif ($_instance->childHasBeenRendered('iYr0ckT')) {
    $componentId = $_instance->getRenderedChildComponentId('iYr0ckT');
    $componentTag = $_instance->getRenderedChildComponentTagName('iYr0ckT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iYr0ckT');
} else {
    $response = \Livewire\Livewire::mount('mini-nav-bar', ['tmp' => 2]);
    $html = $response->html();
    $_instance->logRenderedChild('iYr0ckT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<div class="mt-md-5 mt-3 mx-2">
    <div class="row justify-content-center">
        <div class="col-xl-10 col-md-10">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('display-object-full', ['object_id' => $trailer->id])->html();
} elseif ($_instance->childHasBeenRendered('4tZfmq1')) {
    $componentId = $_instance->getRenderedChildComponentId('4tZfmq1');
    $componentTag = $_instance->getRenderedChildComponentTagName('4tZfmq1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4tZfmq1');
} else {
    $response = \Livewire\Livewire::mount('display-object-full', ['object_id' => $trailer->id]);
    $html = $response->html();
    $_instance->logRenderedChild('4tZfmq1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>
    </div>      
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\inz\resources\views/trailers/show.blade.php ENDPATH**/ ?>