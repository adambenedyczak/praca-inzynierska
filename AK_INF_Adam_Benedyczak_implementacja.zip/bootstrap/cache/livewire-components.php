<?php return array (
  'add-new-element' => 'App\\Http\\Livewire\\AddNewElement',
  'add-new-object' => 'App\\Http\\Livewire\\AddNewObject',
  'display-element' => 'App\\Http\\Livewire\\DisplayElement',
  'display-elements' => 'App\\Http\\Livewire\\DisplayElements',
  'display-object' => 'App\\Http\\Livewire\\DisplayObject',
  'display-object-full' => 'App\\Http\\Livewire\\DisplayObjectFull',
  'edit-object' => 'App\\Http\\Livewire\\EditObject',
  'mini-nav-bar' => 'App\\Http\\Livewire\\MiniNavBar',
  'notification-settings' => 'App\\Http\\Livewire\\NotificationSettings',
  'notifications-bar' => 'App\\Http\\Livewire\\NotificationsBar',
);