<?php

namespace App\Http\Livewire;

use Livewire\Component;

class MiniNavBar extends Component
{
    public $tmp;

    public function render()
    {
        return view('livewire.mini-nav-bar');
    }
}
