<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Mail\SendMail;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class NotificationsScheduler extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notifications:scheduler';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Prepare daily notifications for users';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //tutaj kod
        $today = Carbon::now()->format('Y-m-d');
        //$notifications = Notification::with('user', 'event', 'element_category')
        //                            ->where('send', '=', $today)
        $users = User::all();
        foreach ($users as $user) {
            Mail::raw("Test mail", function ($mail) use ($user) {
                $mail->from('nazwa_maila@tmm.pl');
                $mail->to($user->email)
                    ->subject('Twoja wiadomość!');
            });
            $this->info('Wiadomość wysłana do '.$user->name );
        }

    }
}
